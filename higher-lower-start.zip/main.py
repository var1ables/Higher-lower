
from art import logo
from art import vs
from game_data import data
import random
#from replit import clear

#print sick ascii logo
print(logo)




#definited the game function that will run most of the code
def game():
  #defined the variable that will be true for the whole game
  higher_lower = True
  while higher_lower == True:
    #defined the count of correct answers the users has
    count = 0
    
    #pull first value from the game_data.py file 
    b_unformatted = random.choice(data)
    #create the b variable that will be shifted to a
    a_unformatted = b_unformatted

    #defined the variable that will be true for the second while loop
    game = True
    while game == True:
      print(f'You are comparing {b_unformatted["name"]}.')
      #printed sick ascii art
      print(vs)
      #define second variable being run
      b_unformatted = random.choice(data)
      print(f"to {b_unformatted['name']}")

      #created the crux of the game as an input
      user_input = input('Which do you think has more instagram followers? A or B\n').lower()
      
      #compared the first option to the second based the user input
      if user_input == "a": 
        if a_unformatted['follower_count'] > b_unformatted['follower_count']:
          print('You chose correctly! congratulations!')
          count = count + 1
          #clear()

        else:
          print(f'You chose wrong :(. You played a total of {count} times.')
          game = False
          higher_lower = False  
          
      elif user_input == "b":
        if b_unformatted['follower_count'] > a_unformatted['follower_count']:
          print('You chose correctly! congratulations!')
          count = count + 1
          #clear()

        else:
          print(f'You chose wrong :(. You played a total of {count} times.')
          game = False
          higher_lower = False
     #killed the game if any other input is selected
      else:
        print("congrats you broke it.")
        game = False
        higher_lower = False
          
        
    
#calling the function to start the game    
game()